var classcom_1_1twix_1_1tailoredtravels_1_1_google_earth_path =
[
    [ "GoogleEarthPath", "classcom_1_1twix_1_1tailoredtravels_1_1_google_earth_path.html#aa15740bee3373d47996df6c15a35f221", null ],
    [ "GoogleEarthPath", "classcom_1_1twix_1_1tailoredtravels_1_1_google_earth_path.html#a1da903f382a47ac383873b558fe093e4", null ],
    [ "addWaypoint", "classcom_1_1twix_1_1tailoredtravels_1_1_google_earth_path.html#a8a45aedd969a5ecdfdaccee3cc83a449", null ],
    [ "getPath", "classcom_1_1twix_1_1tailoredtravels_1_1_google_earth_path.html#add0dbbb86bc1b39af5a41baec63c2577", null ]
];