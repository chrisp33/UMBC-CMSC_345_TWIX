var searchData=
[
  ['databasemanager',['DatabaseManager',['../classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a5fd81387462021f3a2c234596d7e669f',1,'com::twix::tailoredtravels::DatabaseManager']]],
  ['dist',['dist',['../classcom_1_1twix_1_1tailoredtravels_1_1_dist_calc_driver.html#ac157f7fde2a521a42b6d8c743d61c75c',1,'com::twix::tailoredtravels::DistCalcDriver']]],
  ['distance',['distance',['../classcom_1_1twix_1_1tailoredtravels_1_1_lat_long_pair.html#afe76298eaa3ba7818803b3cbabbbba7c',1,'com.twix.tailoredtravels.LatLongPair.distance()'],['../classcom_1_1twix_1_1tailoredtravels_1_1_waypoint.html#ab533fb412000d0e8dd40ec688fcf5af1',1,'com.twix.tailoredtravels.Waypoint.distance()']]]
];
