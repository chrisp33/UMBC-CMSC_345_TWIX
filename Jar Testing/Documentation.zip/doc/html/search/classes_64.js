var searchData=
[
  ['databasemanager',['DatabaseManager',['../classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html',1,'com::twix::tailoredtravels']]],
  ['distcalcdriver',['DistCalcDriver',['../classcom_1_1twix_1_1tailoredtravels_1_1_dist_calc_driver.html',1,'com::twix::tailoredtravels']]]
];
