var searchData=
[
  ['newdatabase',['newDatabase',['../classcom_1_1twix_1_1init_1_1_init_database.html#a31f1547285d8a43059fb42acf8438434',1,'com::twix::init::InitDatabase']]]
];
