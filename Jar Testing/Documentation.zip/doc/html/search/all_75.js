var searchData=
[
  ['updatejlist',['updateJList',['../classcom_1_1twix_1_1tailoredtravels_1_1_menu_panel.html#a3f44b3bda0c13cd20e55712f05a9a37b',1,'com::twix::tailoredtravels::MenuPanel']]],
  ['url',['url',['../classcom_1_1twix_1_1init_1_1_init_database.html#a5e9de9bc6a80da907b9b8ef40c6683b4',1,'com::twix::init::InitDatabase']]]
];
