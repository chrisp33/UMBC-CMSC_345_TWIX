var searchData=
[
  ['initdatabase',['InitDatabase',['../classcom_1_1twix_1_1init_1_1_init_database.html',1,'com::twix::init']]],
  ['initdatabase_2ejava',['InitDatabase.java',['../_init_database_8java.html',1,'']]],
  ['isuseradmin',['isUserAdmin',['../classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a2ccf63adbc938676d9bafbf43667261a',1,'com::twix::tailoredtravels::DatabaseManager']]]
];
