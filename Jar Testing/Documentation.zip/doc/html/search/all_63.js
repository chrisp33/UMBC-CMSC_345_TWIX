var searchData=
[
  ['client',['Client',['../classcom_1_1twix_1_1tailoredtravels_1_1_client.html',1,'com::twix::tailoredtravels']]],
  ['client_2ejava',['Client.java',['../_client_8java.html',1,'']]],
  ['com',['com',['../namespacecom.html',1,'']]],
  ['init',['init',['../namespacecom_1_1twix_1_1init.html',1,'com::twix']]],
  ['tailoredtravels',['tailoredtravels',['../namespacecom_1_1twix_1_1tailoredtravels.html',1,'com::twix']]],
  ['twix',['twix',['../namespacecom_1_1twix.html',1,'com']]]
];
