var searchData=
[
  ['main',['main',['../classcom_1_1twix_1_1init_1_1_init_database.html#ae34ebcf5fd998c49414bffe96711c09e',1,'com.twix.init.InitDatabase.main()'],['../classcom_1_1twix_1_1tailoredtravels_1_1_client.html#a781f21b89856adb998c7929b4221923e',1,'com.twix.tailoredtravels.Client.main()'],['../classcom_1_1twix_1_1tailoredtravels_1_1_lat_long_pair.html#afb325ba5da71762d52a02d9c0a2af44f',1,'com.twix.tailoredtravels.LatLongPair.main()']]],
  ['menupanel',['MenuPanel',['../classcom_1_1twix_1_1tailoredtravels_1_1_menu_panel.html#aa85bfae72b9b9077e404b43b71789250',1,'com::twix::tailoredtravels::MenuPanel']]]
];
