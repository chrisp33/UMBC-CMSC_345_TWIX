var searchData=
[
  ['latlongpair',['LatLongPair',['../classcom_1_1twix_1_1tailoredtravels_1_1_lat_long_pair.html#a954bc334e0655d6aba61889148763c59',1,'com.twix.tailoredtravels.LatLongPair.LatLongPair(String label, double x, double y)'],['../classcom_1_1twix_1_1tailoredtravels_1_1_lat_long_pair.html#a31d06b625d306f8c9fec890088e057e8',1,'com.twix.tailoredtravels.LatLongPair.LatLongPair()']]],
  ['login',['login',['../classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a7ad514c70febbb99b14d8a4dab1b24a6',1,'com::twix::tailoredtravels::DatabaseManager']]],
  ['logout',['logout',['../classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a3fe7ef841c1340941920745cc00a39ab',1,'com::twix::tailoredtravels::DatabaseManager']]]
];
