var searchData=
[
  ['latlongpair',['LatLongPair',['../classcom_1_1twix_1_1tailoredtravels_1_1_lat_long_pair.html',1,'com::twix::tailoredtravels']]]
];
