var classcom_1_1twix_1_1tailoredtravels_1_1_database_manager =
[
    [ "DatabaseManager", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a5fd81387462021f3a2c234596d7e669f", null ],
    [ "addLocation", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a19c56c261a486a909936cf7c97334360", null ],
    [ "addUser", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#ab60c1da42acf1d6ecc8955aa58da3803", null ],
    [ "getWaypoints", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a4e594f8a6f845de1fe5ab29e5430ba9e", null ],
    [ "isUserAdmin", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a2ccf63adbc938676d9bafbf43667261a", null ],
    [ "login", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a7ad514c70febbb99b14d8a4dab1b24a6", null ],
    [ "logout", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a3fe7ef841c1340941920745cc00a39ab", null ],
    [ "printWaypoints", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#ac69a6164612bb086c72c54440d32f3de", null ],
    [ "removeLocation", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#ac60ff9d81a074ef84eb0f6ced1fa7fde", null ],
    [ "removeUser", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a73d155c07d2ed41e8c596323184da135", null ],
    [ "setWaypointDescription", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#aa8c98a1bfb16ebdbd8d3eeb6e9d80a73", null ],
    [ "setWaypointLatLong", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a0b8a3295e6857761b89a8db4d048d5a4", null ],
    [ "setWaypointName", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html#a4c8078e19441474ebb02fd67dfe9d3b4", null ]
];