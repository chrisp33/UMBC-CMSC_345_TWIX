var namespacecom_1_1twix_1_1init =
[
    [ "InitDatabase", "classcom_1_1twix_1_1init_1_1_init_database.html", null ]
];