var dir_4349b05a0d95e08b128f4765a68dceb7 =
[
    [ "InitDatabase.java", "_init_database_8java.html", [
      [ "InitDatabase", "classcom_1_1twix_1_1init_1_1_init_database.html", null ]
    ] ]
];