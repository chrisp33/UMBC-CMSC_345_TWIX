var namespacecom_1_1twix =
[
    [ "init", "namespacecom_1_1twix_1_1init.html", "namespacecom_1_1twix_1_1init" ],
    [ "tailoredtravels", "namespacecom_1_1twix_1_1tailoredtravels.html", "namespacecom_1_1twix_1_1tailoredtravels" ]
];