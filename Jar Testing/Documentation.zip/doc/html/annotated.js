var annotated =
[
    [ "com", "namespacecom.html", "namespacecom" ]
];