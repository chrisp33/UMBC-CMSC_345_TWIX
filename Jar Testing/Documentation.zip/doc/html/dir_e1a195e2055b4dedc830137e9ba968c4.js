var dir_e1a195e2055b4dedc830137e9ba968c4 =
[
    [ "init", "dir_4349b05a0d95e08b128f4765a68dceb7.html", "dir_4349b05a0d95e08b128f4765a68dceb7" ],
    [ "tailoredtravels", "dir_b0606bd208ffb24f2e97f13fc9406cd4.html", "dir_b0606bd208ffb24f2e97f13fc9406cd4" ]
];