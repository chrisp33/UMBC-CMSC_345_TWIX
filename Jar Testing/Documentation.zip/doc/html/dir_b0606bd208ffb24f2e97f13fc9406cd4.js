var dir_b0606bd208ffb24f2e97f13fc9406cd4 =
[
    [ "Client.java", "_client_8java.html", [
      [ "Client", "classcom_1_1twix_1_1tailoredtravels_1_1_client.html", null ]
    ] ],
    [ "DatabaseManager.java", "_database_manager_8java.html", [
      [ "DatabaseManager", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager.html", "classcom_1_1twix_1_1tailoredtravels_1_1_database_manager" ]
    ] ],
    [ "DistCalcDriver.java", "_dist_calc_driver_8java.html", [
      [ "DistCalcDriver", "classcom_1_1twix_1_1tailoredtravels_1_1_dist_calc_driver.html", null ]
    ] ],
    [ "GoogleEarthManager.java", "_google_earth_manager_8java.html", [
      [ "GoogleEarthManager", "classcom_1_1twix_1_1tailoredtravels_1_1_google_earth_manager.html", "classcom_1_1twix_1_1tailoredtravels_1_1_google_earth_manager" ]
    ] ],
    [ "GoogleEarthPath.java", "_google_earth_path_8java.html", [
      [ "GoogleEarthPath", "classcom_1_1twix_1_1tailoredtravels_1_1_google_earth_path.html", "classcom_1_1twix_1_1tailoredtravels_1_1_google_earth_path" ]
    ] ],
    [ "LatLongPair.java", "_lat_long_pair_8java.html", [
      [ "LatLongPair", "classcom_1_1twix_1_1tailoredtravels_1_1_lat_long_pair.html", "classcom_1_1twix_1_1tailoredtravels_1_1_lat_long_pair" ]
    ] ],
    [ "MenuPanel.java", "_menu_panel_8java.html", [
      [ "MenuPanel", "classcom_1_1twix_1_1tailoredtravels_1_1_menu_panel.html", "classcom_1_1twix_1_1tailoredtravels_1_1_menu_panel" ]
    ] ],
    [ "ProgressBar.java", "_progress_bar_8java.html", [
      [ "ProgressBar", "classcom_1_1twix_1_1tailoredtravels_1_1_progress_bar.html", "classcom_1_1twix_1_1tailoredtravels_1_1_progress_bar" ]
    ] ],
    [ "Waypoint.java", "_waypoint_8java.html", [
      [ "Waypoint", "classcom_1_1twix_1_1tailoredtravels_1_1_waypoint.html", "classcom_1_1twix_1_1tailoredtravels_1_1_waypoint" ]
    ] ]
];